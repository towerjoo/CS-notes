#! /usr/bin/env python
# coding: utf-8

# 1 tab = 4 spaces

"""
文件名: %(filename)s
作者: %(author)s
日期: %(date)s
说明: %(description)s

"""

#######################################################
# 这个文件是此app对应的model在admin中显示所需要的文件
# 可以更改,来获得不同的显示和功能
# 具体可参考django admin的文档说明
#######################################################


# 引入标准module

# 引入django module
from django.contrib import admin

#引入第三方module

# 引入本项目中的module
from models import *

class %(classname)sAdmin(admin.ModelAdmin):
    list_display = ('id','name','sex','reg_date','status')  #列出需要在admin中显示的表域
    search_fields = ['name']    # 列出可以搜索的域
admin.site.register(User, %(classname)sAdmin)

